import React from 'react';

function Profile() {
  return (
    <div>
      <h1>Profile Page</h1>
      {/* Your profile details here */}
    </div>
  );
}

export default Profile;