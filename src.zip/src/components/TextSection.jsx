// TextSection.js
import React from "react";
import "./TextSection.css"; // Import CSS for the text section

function TextSection() {
  return (
    <div className="text-section">
      <h2>Get the size you need. Now you don't need to compromise on what size you want!</h2>
    </div>
  );
}

export default TextSection;
