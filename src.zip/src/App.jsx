import React from 'react';
import Navbar from './components/Navbar';
import Carousel from './components/Carousel';
import TextSection from './components/TextSection';
import './App.css';
import CarouselData from './data/CarouselData.json'; // Ensure this file exists and is named correctly

function App() {
  return (
    <>
      <Navbar />
      <div className="app-container">
        <Carousel data={CarouselData} />
        <div className="media-container">
          <TextSection />
          <div className="video-container">
            <video width="320" height="200" autoPlay muted loop>
              <source 
                src="https://videos.pexels.com/video-files/4620477/4620477-uhd_1440_2732_25fps.mp4" 
                type="video/mp4" 
              />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
